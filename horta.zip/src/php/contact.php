<?php

header('Content-Type: text/html; charset=utf-8');
require_once 'phpmailer/PHPMailerAutoload.php';

// require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/haut-2/phpmailer/PHPMailerAutoload.php';


if (isset($_POST['name'])) {

    $data = new DateTime();

    $mensagem = "<h3>NOVO LEAD</h3>";

    $mensagem .= "<br />";

    $mensagem .= "<b>Nome:</b> " . utf8_decode($_POST['name']);

    $mensagem .= "<br />";

    $mensagem .= "<b>E-mail:</b> " . utf8_decode($_POST['email']);

    $mensagem .= "<br />";

    $mensagem .= "<b>Whatsapp:</b> " . utf8_decode($_POST['whatsapp']);

    $mensagem .= "<br />";

    $mensagem .= "<b>Data e hora do cadastro:</b> " . $data->format('d/m/Y H:i');

    $mensagem .= "<br /><br /><br />";

    $mensagem .= utf8_decode("Observação: Este formulário foi enviado através da LANDINGPAGE Horttas");

    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;

    $mail->isSMTP();

    $mail->Host = 'smtp.gmail.com';

    $mail->SMTPAuth = true;

    $mail->SMTPSecure = "tls";

    $mail->Username = "hortta.desenvolvimento@gmail.com";

    $mail->Password = "hortta2020";

    $mail->Port = 587;

    $mail->setFrom('horttas@horttas.com.br', utf8_decode('Formulário LP - Hortta'));

    $mail->addAddress('horttas@horttas.com.br', utf8_decode('Formulário LP - Hortta'));

    $mail->isHTML(true);

    $mail->Subject = utf8_decode('[Formulário LP - Hortta.] Enviado por ' . utf8_decode("teste"));

    $mail->Body = ($mensagem);

    $mail->AltBody = nl2br(strip_tags($mensagem));

    if ($mail->send()) {
        echo "success";
    }

} else {
    echo "error";
}
